# Chanak Landing

Landing page para Chanak International Academy.

## Despliegue en Vercel

1. Subir estos archivos a GitHub.
2. Importar el repositorio en Vercel.
3. Framework: Next.js.
4. Build command: `npm run build`.
5. Configurar variables de entorno si se activa Brevo:
   - BREVO_API_KEY
   - BREVO_LIST_ID

## Nota

El archivo principal está en `app/page.jsx`.
La API preparada para Brevo está en `app/api/brevo-lead/route.js`.
